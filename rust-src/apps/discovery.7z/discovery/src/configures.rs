
use async_std::path::PathBuf;
use near_core::get_data_path;
use once_cell::sync::OnceCell;

use near_base::{DeviceObject, FileDecoder};

pub struct Configures {
    pub(crate) desc: DeviceObject,
}

impl Configures {
    pub fn get_instance() -> &'static Self {
        static INSTACNE: OnceCell<Configures> = OnceCell::new();
        INSTACNE.get_or_init(||{
            let desc = 
                DeviceObject::decode_from_file(
                    get_data_path().join(PathBuf::new().with_file_name("core-service").with_extension("desc")).as_path()
                )
                .expect("failed get");

            Self {
                desc
            }
        })
    }
}
