
use std::any::Any;

use near_base::Deserialize;

pub mod v0;

type PackageBodyTrait = Box<dyn Any + Send + Sync>;

#[repr(u8)]
#[derive(Clone, Copy, Default)]
pub enum Command {
    #[default]
    None = 0,
    Search = 1,
    SearchResp = 2,
}

impl TryFrom<u8> for Command {
    type Error = near_base::NearError;

    fn try_from(value: u8) -> Result<Self, Self::Error> {
        match value {
            1u8 => Ok(Command::Search),
            2u8 => Ok(Command::SearchResp),
            _ => Err(near_base::NearError::new(near_base::ErrorCode::NEAR_ERROR_UNDEFINED, format!("undefined [{value}] command")))
        }        
    }
}

#[derive(Default)]
pub struct Head {
    pub(crate) ver: u8,
    pub(crate) cmd: Command,
    pub(crate) uid: u32,
}

impl near_base::Serialize for Head {
    fn raw_capacity(&self) -> usize {
        self.ver.raw_capacity() + 
        (self.cmd as u8).raw_capacity()
    }

    fn serialize<'a>(&self,
                     buf: &'a mut [u8]) -> near_base::NearResult<&'a mut [u8]> {
        let buf = self.ver.serialize(buf)?;
        let buf = (self.cmd as u8).serialize(buf)?;
        let buf = self.uid.serialize(buf)?;

        Ok(buf)
    }
}

impl near_base::Deserialize for Head {
    fn deserialize<'de>(buf: &'de [u8]) -> near_base::NearResult<(Self, &'de [u8])> {
        let (ver, buf) = u8::deserialize(buf)?;
        let (cmd, buf) = u8::deserialize(buf)?;
        let (uid, buf) = u32::deserialize(buf)?;

        Ok((Self {
            ver,
            cmd: cmd.try_into()?,
            uid,
        }, buf))
    }
}

pub struct DynamicPackage {
    head: Head,
    body: PackageBodyTrait,
}

unsafe impl Send for DynamicPackage {}
unsafe impl Sync for DynamicPackage {}

impl DynamicPackage {
    pub fn parse(text: &[u8]) -> near_base::NearResult<Self> {
        let (head, text) = Head::deserialize(&text)?;

        let data = 
            match head.cmd {
                Command::Search => {
                    let (data, _) = v0::Search::deserialize(text)?;
                    data
                }
                _ => unimplemented!()
            };

        Ok(Self{
            head,
            body: Box::new(data),
        })

    }

    pub fn take_head(&mut self) -> Head {
        std::mem::replace(&mut self.head, Default::default())
    }

    pub fn take_body<T>(&mut self) -> T where T: 'static + std::default::Default {
        let body = self.body.downcast_mut::<T>().unwrap();

        std::mem::replace(body, T::default())
    }

    // pub fn split<T: 'static + Default>(self) -> (PackageHeader, PackageHeaderExt, T, Option<Signature>) {
}

// fn recv_package<T>(text: &[u8]) -> NearResult<Head, T>
// where T: PackageBodyTrait {

//     if head.ver != 1u8 {
//         Err(NearError::new(ErrorCode::NEAR_ERROR_INVALIDPARAM, "version is invalid"))
//     } else {
//         Ok(())
//     }

//     match head.cmd {
//         Command::Search => 
//     }

//     Ok(())
// }

