# Intel tests

Directories based on [List of Intel CPU microarchitectures](https://en.wikipedia.org/wiki/List_of_Intel_CPU_microarchitectures).  
Each sub-directory is named after the micro-architecture.
